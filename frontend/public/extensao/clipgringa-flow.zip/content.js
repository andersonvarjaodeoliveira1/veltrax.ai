/* ClipGringa · Flow (Lower Priority)
 * Roda dentro de https://flow.google.com/project/*. Lê o pacote do ClipGringa e, para cada cena:
 * 1) gera a imagem (Nano Banana, 9:16)  2) anima com Veo 3.1 Lite [Lower Priority] usando a imagem como primeiro quadro
 * 3) baixa o vídeo como VideoXX_CenaYY.mp4. Tudo na sessão do próprio membro, sem senha e sem gastar créditos.
 */
(function () {
  "use strict";
  if (window.__clipgringaFlow) return;
  window.__clipgringaFlow = true;

  const STORE_KEY = "clipgringa-flow-state-v1";
  const IMAGE_WAIT_MS = 4 * 60 * 1000;
  const VIDEO_WAIT_MS = 25 * 60 * 1000;
  const RETRIES = 3;
  let roundNo = 0; // 0 = primeira rodada; 2 = último recurso (anima só pelo texto, espera mais)

  // Dorme em fatias curtas e, se o membro clicou em Parar, aborta na hora (em vez de esperar a etapa acabar).
  const sleep = async (ms) => {
    const end = Date.now() + ms;
    for (;;) {
      if (typeof running !== "undefined" && running && typeof stopFlag !== "undefined" && stopFlag) throw new Error("STOP");
      const left = end - Date.now();
      if (left <= 0) return;
      await new Promise((r) => setTimeout(r, Math.min(left, 200)));
    }
  };
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const visible = (el) => !!el && el.getBoundingClientRect().width > 0 && el.getBoundingClientRect().height > 0;
  const text = (el) => ((el && el.innerText) || "").trim();
  const pad = (n) => String(n).padStart(2, "0");

  async function waitFor(fn, timeout = 8000, step = 150) {
    const end = Date.now() + timeout;
    for (;;) {
      let value = null;
      try { value = fn(); } catch (_e) { value = null; }
      if (value) return value;
      if (Date.now() > end) return null;
      await sleep(step);
    }
  }

  /* ---------- estado salvo (sobrevive a recarregar a página) ---------- */
  const storage = {
    async get() {
      try {
        if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
          const got = await chrome.storage.local.get(STORE_KEY);
          return got[STORE_KEY] || null;
        }
      } catch (_e) { /* ignora */ }
      try { return JSON.parse(localStorage.getItem(STORE_KEY) || "null"); } catch (_e) { return null; }
    },
    async set(value) {
      try {
        if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
          await chrome.storage.local.set({ [STORE_KEY]: value });
          return;
        }
      } catch (_e) { /* ignora */ }
      try { localStorage.setItem(STORE_KEY, JSON.stringify(value)); } catch (_e) { /* ignora */ }
    },
  };

  /* ---------- pacote ---------- */
  let flowModel = "[Lower Priority]"; // modelo do Flow pedido pelo pacote (padrão: Lower Priority, 0 créditos)
  let productImage = ""; // foto real do produto (data URL) enviada pelo site: vai como referência na imagem de cada cena
  let refDone = false;
  const sceneImages = {}; // imagem já criada de cada cena: se só o vídeo falhar, a próxima rodada reaproveita (não gasta outra imagem)
  const baselines = new Map(); // peças que já existiam antes de cada cena começar (não vai para o estado salvo)
  const claimedTiles = new Set(); // peças da grade do Flow que já pertencem a uma cena
  let fallbackModels = []; // modelos mais baratos a tentar quando a conta não tem o pedido (ex.: sem Lower Priority)
  const isLowerPriority = () => flowModel === "[Lower Priority]";

  function parsePackage(raw) {
    let data;
    try { data = JSON.parse(raw); } catch (_e) { throw new Error("O texto colado não é um pacote válido do ClipGringa."); }
    if (!data || data.app !== "clipgringa-flow" || !Array.isArray(data.videos) || !data.videos.length) {
      throw new Error("Esse não é um pacote do ClipGringa (falta a lista de vídeos).");
    }
    const jobs = [];
    data.videos.forEach((video, vi) => {
      (video.scenes || []).forEach((scene, si) => {
        if (!scene.imagePrompt || !scene.videoPrompt) return;
        jobs.push({
          key: `${vi}-${si}`,
          vi, si,
          vname: String(video.label || `Vídeo ${pad(vi + 1)}`),
          sname: String(scene.label || `Cena ${pad(si + 1)}`),
          vbase: Number.isInteger(video.base) ? video.base : vi,
          sbase: Number.isInteger(scene.src) ? scene.src : si,
          title: video.title || `Vídeo ${pad(vi + 1)}`,
          imagePrompt: String(scene.imagePrompt),
          videoPrompt: String(scene.videoPrompt),
          file: scene.file || `Video${pad(vi + 1)}_Cena${pad(si + 1)}.mp4`,
        });
      });
    });
    if (!jobs.length) throw new Error("O pacote não tem cenas com prompts.");
    const wanted = String(data.flowModel || "").trim();
    flowModel = wanted && !/lower priority/i.test(wanted) ? wanted : "[Lower Priority]";
    productImage = data.attachProduct === true && typeof data.productImage === "string" && /^data:image\/(jpeg|png|webp);base64,/.test(data.productImage) ? data.productImage : "";
    refDone = false;
    fallbackModels = Array.isArray(data.fallbackModels) ? data.fallbackModels.map((x) => String(x)).filter(Boolean) : [];
    try { el("chipmodel").textContent = isLowerPriority() ? "LOWER PRIORITY · 0 CRÉDITOS" : `${flowModel.toUpperCase()} · GASTA CRÉDITOS`; } catch (_e) { /* painel ainda não existe */ }
    return { jobs, keyword: data.keyword || "" };
  }

  /* ---------- Flow: caixa de prompt e ajustes ---------- */
  // Outras versões do Flow usam outro tipo de campo de texto: procura qualquer campo editável visível e largo, o mais baixo da tela.
  const genericEditor = () => {
    const cands = $$('[contenteditable="true"], [contenteditable=""], [role="textbox"], textarea', document)
      .filter((n) => visible(n) && !n.closest("#clipgringa-flow-host") && n.getBoundingClientRect().width > 120 && !/search|pesquis|busca/i.test(`${n.getAttribute("aria-label") || ""} ${n.getAttribute("placeholder") || ""}`));
    if (!cands.length) return null;
    return cands.sort((x, y) => y.getBoundingClientRect().bottom - x.getBoundingClientRect().bottom)[0];
  };
  const promptBox = () => $(".base-prompt-box") || $(".ProseMirror")?.closest("div") || genericEditor()?.parentElement || null;
  const editor = () => $(".base-prompt-box .ProseMirror") || $(".ProseMirror") || genericEditor();
  const overlay = () => $(".cdk-overlay-container") || document.body;

  function radios() { return $$("button[role=radio]", overlay()); }
  const hasIcon = (b, icon) => text(b).split("\n").map((s) => s.trim()).includes(icon);
  const isOn = (b) => b.getAttribute("aria-checked") === "true" || b.getAttribute("aria-pressed") === "true" || b.classList.contains("mat-button-toggle-checked");

  const settingsTrigger = () => {
    const exact = $(".settings-trigger-button") || $("button[class*=settings-trigger]");
    if (exact) return exact;
    const label = (b) => `${b.getAttribute("aria-label") || ""} ${b.title || ""} ${text(b)}`;
    const re = /ajustes|configura|settings|tune/i;
    // o botão de ajustes da caixa de criação fica junto da caixa de texto (o "Configurações" solto da página não serve)
    let node = $(".ProseMirror") || genericEditor();
    for (let i = 0; node && i < 8; i += 1, node = node.parentElement) {
      const hit = $$("button", node).filter(visible).find((b) => re.test(label(b)));
      if (hit) return hit;
    }
    return null;
  };

  // O Flow pode abrir o painel do "Agente" (chat). Para gerar direto, esse painel precisa estar fechado.
  async function closeAgentPanel() {
    const panel = $(".agent-panel-wrapper");
    if (!panel || !visible(panel)) return;
    const header = $(".agent-panel-header", document) || panel;
    const close = $$("button", header).filter(visible).find((b) => text(b) === "close" || /fechar|close|dismiss/i.test(b.getAttribute("aria-label") || b.title || ""));
    if (close) { close.click(); await sleep(1200); return; }
    // sem botão de fechar conhecido: tenta o Esc
    document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", keyCode: 27, bubbles: true }));
    await sleep(900);
  }

  /** Resumo curto do que a aba do Flow mostra agora (vai junto do erro para dar para entender o que mudou). */
  function flowDiagnosis() {
    const panel = $(".agent-panel-wrapper");
    const buttons = $$("button", document).filter(visible).map((b) => (b.getAttribute("aria-label") || b.title || text(b)).replace(/\s+/g, " ").trim()).filter(Boolean).slice(0, 30);
    const fields = $$('[contenteditable], [role="textbox"], textarea, input[type=text]', document).filter(visible).filter((n) => !n.closest("#clipgringa-flow-host")).slice(0, 5)
      .map((n) => `${n.tagName.toLowerCase()}.${String(n.className || "").split(" ")[0]}[${(n.getAttribute("aria-label") || n.getAttribute("placeholder") || "").slice(0, 24)}]`);
    return `página ${location.pathname.slice(0, 48)}; Agente ${panel && visible(panel) ? "aberto" : "fechado"}; caixa de texto ${editor() ? "sim" : "não"}; ajustes ${settingsTrigger() ? "sim" : "não"}; janela ${innerWidth}x${innerHeight}; campos: ${fields.join(" ") || "nenhum"}; botões: ${buttons.join(" | ") || "nenhum"}`;
  }

  const lastLine = (n) => text(n).split("\n").map((x) => x.trim()).filter(Boolean).pop() || "";
  const outside = (n) => !n.closest("#clipgringa-flow-host");
  const directComposer = () => !!$(".settings-trigger-button") && !!editor();

  /** O Flow abre sozinho a tela de detalhe da imagem (“O que você quer mudar?”). Para gerar a próxima cena, volta ao projeto. */
  async function leaveDetailView() {
    const inDetail = () => /\/project\/[^/]+\/.+/.test(location.pathname)
      || $$("button", document).filter(visible).some((b) => outside(b) && /^concluir$|^done$/i.test(lastLine(b)))
      || /o que você quer mudar|what do you want to change/i.test(document.body.innerText || "");
    if (!inDetail() || directComposer()) return false;
    const back = $$("button, a", document).filter(visible).filter(outside).find((b) => {
      const r = b.getBoundingClientRect();
      return r.left < 220 && r.top < 140 && (/^arrow_back$/i.test(lastLine(b)) || /voltar|back/i.test(b.getAttribute("aria-label") || b.title || ""));
    });
    if (back) back.click(); else history.back();
    await waitFor(() => !inDetail() || directComposer(), 6000);
    await sleep(700);
    return true;
  }

  /** Em algumas contas o Flow abre a caixa de baixo no modo “Agente”: cada pedido vira várias imagens e nada do que a extensão espera existe. Troca para a geração direta. */
  async function leaveAgentMode() {
    if (directComposer()) return false;
    const chip = $$('button, [role="button"], [role="tab"], [role="radio"], mat-chip, [class*="chip"], [class*="mode"]', document)
      .filter(visible).filter(outside).find((n) => /^agente$|^agent$/i.test(lastLine(n)));
    if (!chip) return false;
    await realClick(chip);
    await sleep(900);
    const items = () => $$("[role=menuitem], [role=menuitemradio], [role=option], .mat-mdc-menu-item, .mat-mdc-option", overlay()).filter(visible);
    const choices = items().filter((i) => !/^agente$|^agent$/i.test(lastLine(i)) && !/agente|agent/i.test(text(i).split("\n")[0]));
    const pick = choices.find((i) => /imagem|image|gerar|criar|create|direto|manual|vídeo|video/i.test(text(i))) || choices[0];
    if (pick) { pick.click(); await sleep(900); }
    await waitFor(directComposer, 4000);
    return true;
  }

  async function ensureDirectMode() {
    await closeAgentPanel();
    await leaveDetailView();
    if (!directComposer()) await leaveAgentMode();
    let ok = await waitFor(directComposer, 6000);
    if (!ok) {
      await closeAgentPanel(); // segunda tentativa: o painel pode ter aberto depois
      await leaveDetailView();
      await leaveAgentMode();
      ok = await waitFor(directComposer, 4000);
    }
    if (!ok) {
      const chips = $$('button, [role="button"], mat-chip, [class*="chip"]', document).filter(visible).filter(outside).map(lastLine).filter(Boolean).slice(0, 12).join(" | ");
      throw new Error(`Não achei a caixa de criação do Flow (a que tem os ajustes de imagem e vídeo). Se a caixa de baixo estiver no modo “Agente”, troque para gerar imagem/vídeo direto. [${flowDiagnosis()}; chips: ${chips}]`);
    }
  }

  async function openSettings() {
    if (radios().some(visible)) return true;
    const trigger = settingsTrigger();
    if (!trigger) throw new Error(`Não achei o botão de ajustes do Flow. Abra um projeto do Flow. [${flowDiagnosis()}]`);
    trigger.click();
    const ok = await waitFor(() => radios().some(visible), 5000);
    if (!ok) throw new Error("Os ajustes do Flow não abriram.");
    return true;
  }

  async function closeSettings() {
    for (let i = 0; i < 3; i += 1) {
      if (!radios().some(visible) && !$$(".mat-mdc-menu-panel", overlay()).some(visible)) return;
      document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", keyCode: 27, bubbles: true }));
      const active = document.activeElement;
      if (active) active.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", keyCode: 27, bubbles: true }));
      await sleep(350);
    }
    if (radios().some(visible)) {
      const trigger = $(".settings-trigger-button");
      if (trigger) trigger.click();
      await sleep(350);
    }
  }

  async function pickRadio(icon) {
    const btn = await waitFor(() => radios().find((b) => visible(b) && hasIcon(b, icon)), 3000);
    if (!btn) return false;
    if (!isOn(btn)) { btn.click(); await sleep(450); }
    return true;
  }

  async function pickRadioByLabel(label) {
    const btn = await waitFor(() => radios().find((b) => visible(b) && text(b).replace(/\s+/g, "") === label), 3000);
    if (!btn) return false;
    if (!isOn(btn)) { btn.click(); await sleep(450); }
    return true;
  }

  async function ensureModel(needle) {
    const matchesOne = (t, n) => t.includes(n) && (n === "[Lower Priority]" || !/\[Lower Priority\]/i.test(t));
    const trigger = await waitFor(() => $$("button.mat-mdc-menu-trigger", overlay()).find(visible), 3000);
    if (!trigger) return text(null) || "";
    if (matchesOne(text(trigger), needle)) return text(trigger);
    trigger.click();
    const items = () => $$("[role=menuitem], .mat-mdc-menu-item", overlay()).filter(visible);
    let item = await waitFor(() => items().find((i) => matchesOne(text(i), needle)), 4000);
    let used = needle;
    if (!item && fallbackModels.length) {
      // A conta não tem o modelo pedido: usa o mais barato que ela tiver.
      for (const alt of fallbackModels) {
        item = items().find((i) => matchesOne(text(i), alt));
        if (item) { used = alt; break; }
      }
      if (item) { flowModel = used; fallbackModels = []; setNow(`Sua conta não tem “${needle}”. Usando ${text(item).split("\n")[0]} (gasta créditos).`); }
    }
    if (!item) {
      const seen = items().map((i) => text(i).split("\n")[0]).filter(Boolean).slice(0, 6).join(" | ");
      await closeSettings();
      throw new Error(`O Flow não mostrou o modelo “${needle}” nesta conta (modelos que apareceram: ${seen || "nenhum"}). ${needle === "[Lower Priority]" ? "Confira se o Veo 3.1 Lite [Lower Priority] aparece nos ajustes do Flow (ele é do plano Ultra)." : "Confira o nome do modelo nos ajustes do Flow."}`);
    }
    item.click();
    await sleep(500);
    return used;
  }

  let cfgStep = "";
  let cfgDone = ""; // último modo (imagem/vídeo) já ajustado: o Flow guarda os ajustes, então não precisa abrir tudo de novo a cada cena
  async function configure(kind) {
    const steps = async () => {
      cfgStep = "fechando o painel do Agente"; await ensureDirectMode();
      if (cfgDone === kind) return;
      cfgStep = "abrindo os ajustes do Flow"; await openSettings();
      if (kind === "image") {
        cfgStep = "escolhendo imagem"; await pickRadio("image");
        cfgStep = "formato 9:16"; await pickRadio("crop_9_16");
        cfgStep = "quantidade x1"; await pickRadioByLabel("x1");
      } else {
        cfgStep = "escolhendo vídeo"; await pickRadio("videocam");
        await sleep(300);
        cfgStep = "modo Frames (primeiro quadro)"; await pickRadio("crop_free");
        cfgStep = "formato 9:16"; await pickRadio("crop_9_16");
        cfgStep = "duração 8s"; await pickRadioByLabel("8s");
        cfgStep = "quantidade x1"; await pickRadioByLabel("x1");
        cfgStep = `modelo ${flowModel}`; await ensureModel(flowModel);
      }
      cfgStep = "fechando os ajustes"; await closeSettings();
      cfgDone = kind;
    };
    let timer = 0;
    try {
      await Promise.race([
        steps(),
        new Promise((_, reject) => { timer = window.setTimeout(() => reject(new Error(`O Flow não respondeu nos ajustes (travou em: ${cfgStep}). Confira se a aba do Flow está aberta e visível.`)), 75000); }),
      ]);
    } finally { window.clearTimeout(timer); }
  }

  async function setPrompt(value) {
    const ed = await waitFor(editor, 6000);
    if (!ed) throw new Error("Não achei a caixa de prompt do Flow.");
    ed.focus();
    document.execCommand("selectAll", false, null);
    document.execCommand("insertText", false, value);
    await sleep(400);
    if (!text(ed).startsWith(value.slice(0, 20))) {
      // segunda tentativa
      ed.focus();
      document.execCommand("selectAll", false, null);
      document.execCommand("delete", false, null);
      document.execCommand("insertText", false, value);
      await sleep(400);
    }
  }

  const generateButton = () => {
    const ed = editor();
    const isArrow = (b) => text(b).split("\n").map((x) => x.trim()).some((x) => x === "arrow_forward" || x === "arrow_upward" || x === "send" || x === "arrow_upward_alt");
    // sobe da caixa de texto até achar o container que tem a seta de enviar (o promptBox() pode ser só a parte do texto)
    let node = ed;
    for (let i = 0; node && i < 10; i += 1, node = node.parentElement) {
      const hit = $$("button", node).filter(visible).find((b) => isArrow(b) || /gerar|criar|enviar|generate|create|send|submit/i.test(b.getAttribute("aria-label") || b.title || ""));
      if (hit) return hit;
    }
    // último recurso: a seta visível mais perto da caixa de texto, em qualquer lugar da página
    const all = $$("button", document).filter(visible).filter((b) => isArrow(b) || /arrow_upward|send/.test(text(b)));
    if (!all.length) return undefined;
    if (!ed) return all[0];
    const er = ed.getBoundingClientRect();
    const dist = (b) => { const r = b.getBoundingClientRect(); return Math.hypot(r.left + r.width / 2 - (er.right), r.top + r.height / 2 - (er.bottom)); };
    return all.sort((x, y) => dist(x) - dist(y))[0];
  };

  /** Fecha avisos simples do Flow que ficam por cima da caixa (dicas, "entendi"). Não aceita termos nem permissões. */
  async function dismissNotices() {
    const dialogs = $$('[role="dialog"], [role="alertdialog"], .cdk-overlay-pane', document).filter(visible);
    let closed = 0;
    for (const d of dialogs) {
      const ok = $$("button", d).filter(visible).find((x) => /^(entendi|got it|ok|fechar|close|dispensar|dismiss|agora não|not now|pular|skip)$/i.test(text(x).replace(/\s+/g, " ").trim()));
      if (ok) { ok.click(); closed += 1; await sleep(500); }
    }
    return closed;
  }

  async function pressGenerate() {
    await dismissNotices();
    const btn = await waitFor(() => { const b = generateButton(); return b && !b.disabled && b.getAttribute("aria-disabled") !== "true" ? b : null; }, 8000);
    if (!btn) {
      // Sem seta visível (janela pequena ou tela do Flow diferente): tenta o Enter de verdade na caixa de prompt antes de desistir.
      const ed0 = editor();
      if (ed0) {
        const beforeNoBtn = tileKeys();
        ed0.focus();
        try { await chrome.runtime.sendMessage({ type: "clipgringa-key" }); } catch (_) {}
        for (let i = 0; i < 12; i += 1) {
          await sleep(500);
          if (!text(editor() || document.body).trim() || firstTiles(12).some((t) => !beforeNoBtn.has(t.src) || /%/.test(t.info))) return;
        }
      }
      throw new Error(`O botão de gerar do Flow está desativado. [${flowDiagnosis()}]`);
    }
    const before = tileKeys();
    const typed = text(editor() || document.body).trim();
    // Só vale olhando a grade de mídias do Flow (nunca o painel da extensão, que também mostra "%").
    const pctCount = () => { const root = tilesRoot(); if (!root || root === document) return 0; const t = text(root); return (t.match(/\d{1,3}\s*%/g) || []).length + (t.match(/gerando|generating/gi) || []).length; };
    const pctBefore = pctCount();
    const startedNow = () => {
      const ed = editor();
      if (pctCount() > pctBefore) return true; // apareceu uma geração em andamento (%, "gerando") mesmo sem miniatura nova ainda
      if (ed && !text(ed).trim()) return true; // o Flow limpa a caixa ao enviar
      if (ed && typed && text(ed).trim() !== typed) return true; // a caixa mudou (ex.: voltou ao texto de exemplo)
      return firstTiles(12).some((t) => !before.has(t.src) || /%/.test(t.info));
    };
    const settle = async (n = 10) => { for (let i = 0; i < n; i += 1) { await sleep(400); if (startedNow()) return true; } return false; };
    btn.scrollIntoView({ block: "center" });
    const r = btn.getBoundingClientRect();
    // 1) clique confiável (chrome.debugger) — espera mais: o Flow às vezes demora a reagir
    try { await chrome.runtime.sendMessage({ type: "clipgringa-click", x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) }); } catch (_) {}
    if (await settle(20)) return;
    // 2) um aviso pode ter aparecido por cima: fecha e tenta de novo
    if (await dismissNotices()) {
      const again = generateButton();
      if (again) { const q = again.getBoundingClientRect(); try { await chrome.runtime.sendMessage({ type: "clipgringa-click", x: Math.round(q.left + q.width / 2), y: Math.round(q.top + q.height / 2) }); } catch (_) {} }
      if (await settle(12)) return;
    }
    // 3) clique direto com eventos completos
    for (const type of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"]) btn.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
    if (await settle()) return;
    btn.click();
    if (await settle()) return;
    // 4) Enter de verdade na caixa de prompt, depois Enter simulado
    const ed = editor();
    if (ed) {
      ed.focus();
      try { await chrome.runtime.sendMessage({ type: "clipgringa-key" }); } catch (_) {}
      if (await settle()) return;
      for (const type of ["keydown", "keypress", "keyup"]) ed.dispatchEvent(new KeyboardEvent(type, { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true }));
      if (await settle()) return;
    }
    const cur = generateButton();
    const dlg = $$('[role="dialog"], [role="alertdialog"]', document).filter(visible).map((d) => text(d).replace(/\s+/g, " ").trim().slice(0, 90)).join(" / ");
    throw new Error(`Escrevi o prompt, mas o Flow não aceitou o envio. Clique na seta do Flow uma vez; eu continuo daí. [texto na caixa ${text(editor() || document.body).trim().length} letras; seta ${cur ? (cur.disabled ? "desativada" : "ativa") : "não achada"}; aviso: ${dlg || "nenhum"}; ${flowDiagnosis()}]`);
  }

  /* ---------- Flow: grade de mídias ---------- */
  const tilesRoot = () => $("cdk-virtual-scroll-viewport.tiles-container") || document;
  const baseSrc = (src) => String(src || "").split("=")[0];

  function firstTiles(limit = 6) {
    const out = [];
    for (const img of $$("img", tilesRoot())) {
      const src = baseSrc(img.src);
      if (!src || out.some((t) => t.src === src)) continue;
      let node = img;
      for (let i = 0; i < 8 && node.parentElement; i += 1) {
        const up = node.parentElement;
        // nunca sobe até um bloco grande (a página inteira, várias imagens): o texto dele não é do cartão desta cena
        if ((up.innerText || "").length > 400 || up.querySelectorAll("img").length > 3) break;
        node = up;
        if (/%|play_circle|image\n|videocam/.test(node.innerText || "") || node.classList.contains("container")) break;
      }
      out.push({ src, img, tile: node, info: node.innerText || "" });
      if (out.length >= limit) break;
    }
    return out;
  }

  /** Diz por que o Flow marcou a geração como falha, lendo o texto do próprio cartão (política de pessoas conhecidas, conteúdo, créditos). */
  function failReason(info) {
    const t = String(info || "").replace(/arrow_forward|refresh|undo|delete|warning|error_outline/gi, " ").replace(/\s+/g, " ").trim();
    if (/proeminente|prominent|pessoas? (famos|conhecid|p[úu]blic)|public figure|celebrit/i.test(t)) {
      return "O Flow recusou esta cena pela política contra gerar pessoas conhecidas: o rosto da foto, o nome ou o texto lembrou alguém famoso. Gere de novo essa cena (ou troque a foto do avatar); os créditos voltam.";
    }
    if (/cr[ée]ditos|credits|cota|quota|limite|limit/i.test(t) && !/violar/i.test(t)) return "O Flow recusou por falta de créditos ou limite de uso: " + t.slice(0, 140);
    if (/violar|viola|policy|pol[ií]tica|safety|seguran[çc]a|sens[ií]vel/i.test(t)) return "O Flow recusou esta cena por uma política de conteúdo: " + t.slice(0, 160);
    return "O Flow marcou esta geração como falha." + (t ? " (" + t.slice(0, 140) + ")" : "");
  }

  /** Só é falha quando o texto do próprio cartão diz isso (o rodapé "O Flow pode cometer erros" e textos da página não contam). */
  function isFailed(info) {
    const t = String(info || "").replace(/arrow_forward/g, " ").replace(/cometer erros|can make mistakes/gi, " ");
    if (t.length > 400) return false;
    return /falha|failed|n[ãa]o foi poss[ií]vel|something went wrong|algo deu errado|\berro\b|\berror\b/i.test(t);
  }

  const tileKeys = () => new Set(firstTiles(12).map((t) => t.src));

  function pageError() {
    const el = $$(".mat-mdc-snack-bar-label, simple-snack-bar, [role=alert], [class*=error-message]").find(visible);
    return el ? text(el) : "";
  }

  async function waitNewTile(before, kind, timeout, onTick) {
    const end = Date.now() + timeout;
    let lastError = "";
    for (;;) {
      const tiles = firstTiles(6);
      const fresh = tiles.find((t) => !before.has(t.src));
      if (fresh) {
        const generating = /\d+\s*%/.test(fresh.info) || /gerando|generating/i.test(fresh.info);
        const failed = isFailed(fresh.info);
        if (failed) throw new Error(failReason(fresh.info));
        if (!generating && (kind === "image" || /play_circle|videocam|movie/.test(fresh.info) || fresh.tile.querySelector("video"))) {
          if (onTick) onTick(100);
          return fresh;
        }
        const pct = (fresh.info.match(/(\d+)\s*%/) || [])[1];
        if (onTick) onTick(pct ? Number(pct) : null);
      }
      const err = pageError();
      if (err && err !== lastError && /limite|limit|quota|cota|erro|error|falha|failed|não foi possível/i.test(err)) {
        lastError = err;
        if (!fresh) throw new Error(err);
      }
      if (stopFlag) throw new Error("STOP");
      if (Date.now() > end) throw new Error("O Flow demorou demais para terminar.");
      await sleep(1000);
    }
  }

  /* ---------- primeiro quadro (Início) ---------- */
  async function realClick(node) {
    const r = node.getBoundingClientRect();
    try {
      const res = await chrome.runtime.sendMessage({ type: "clipgringa-click", x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) });
      if (res && res.ok) return;
    } catch (_) { /* plano B */ }
    node.click();
  }
  const pickerItems = () => {
    const root = overlay();
    const direct = $$(".asset-item", root).filter(visible);
    if (direct.length) return direct;
    const alt = $$("[class*=asset-item], [class*=asset_item], [role=option], [role=listitem]", root).filter((n) => visible(n) && n.querySelector("img"));
    if (alt.length) return alt;
    return null;
  };
  async function chooseStartFrame(imageSrc, strict) {
    const trigger = await waitFor(() => $$(".frame-trigger").find(visible), 6000);
    if (!trigger) throw new Error("Não achei o campo “Início” do Flow (modo Frames).");
    let items = null;
    for (let attempt = 0; attempt < 3 && !items; attempt += 1) {
      trigger.scrollIntoView({ block: "center" });
      if (attempt === 0) trigger.click(); else await realClick(trigger);
      items = await waitFor(pickerItems, 5000, 250);
    }
    if (!items) {
      const seen = $$("[class]", overlay()).filter(visible).slice(0, 12).map((n) => String(n.className).split(" ")[0]).filter(Boolean);
      throw new Error(`A lista de imagens do Flow não abriu (vi: ${[...new Set(seen)].join(", ") || "nada"}).`);
    }
    await sleep(600);
    const all = pickerItems() || [];
    const idOf = (u) => String(u || "").split("?")[0].split("=")[0].split("/").pop();
    let target = all.find((i) => $$("img", i.parentElement || i).some((im) => baseSrc(im.src) === imageSrc));
    if (!target) target = all.find((i) => $$("img", i.parentElement || i).some((im) => idOf(im.src) && idOf(im.src) === idOf(imageSrc)));
    if (!target && strict && all.length > 1) {
      // No modo rápido a imagem desta cena não é a primeira da lista: sem achar a certa, é melhor tentar de novo do que animar a imagem errada.
      await closeSettings();
      document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", keyCode: 27, bubbles: true }));
      throw new Error(`Início: não achei a imagem desta cena na lista do Flow (${all.length} imagens na lista).`);
    }
    if (!target) target = all[0];
    target.click();
    await sleep(500);
    const add = await waitFor(() => $$("button", overlay()).find((b) => visible(b) && /detail-add|include/i.test(b.className)), 5000);
    if (!add) throw new Error("Não achei o botão “Incluir no comando”.");
    add.click();
    await waitFor(() => !pickerItems(), 5000);
    await sleep(500);
  }

  /* ---------- download ---------- */
  function nameNextDownload(filename, upload) {
    return new Promise((resolve) => {
      try {
        if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
          chrome.runtime.sendMessage({ type: "clipgringa-name", filename, upload: upload || null }, () => resolve());
          return;
        }
      } catch (_e) { /* ignora */ }
      resolve();
    });
  }

  function toBase64(buffer) {
    const bytes = new Uint8Array(buffer);
    let out = "";
    for (let i = 0; i < bytes.length; i += 0x8000) out += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return btoa(out);
  }

  async function sendInParts(file, buffer) {
    const bytes = new Uint8Array(buffer);
    const size = 6 * 1024 * 1024;
    const total = Math.max(1, Math.ceil(bytes.length / size));
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    let reply = null;
    for (let index = 0; index < total; index += 1) {
      const part = bytes.subarray(index * size, (index + 1) * size);
      reply = await chrome.runtime.sendMessage({ type: "clipgringa-upload-part", id, index, total, upload: uploadInfo, file, b64: toBase64(part) });
      if (!reply || !reply.ok) return reply;
    }
    return reply;
  }

  // Lê o vídeo pronto direto do card do Flow e manda para o ClipGringa. Devolve true se enviou.
  async function uploadVideo(tile, job) {
    if (!uploadInfo) return false;
    try {
      const v = tile.tile.querySelector("video");
      const src = v && (v.currentSrc || v.src);
      if (!src) throw new Error("o card não mostra o endereço do vídeo");
      const res = await fetch(src, { credentials: "include" });
      if (!res.ok) throw new Error(`o Flow respondeu ${res.status}`);
      const buffer = await res.arrayBuffer();
      if (buffer.byteLength > 120 * 1024 * 1024) throw new Error("vídeo grande demais");
      // Em pedaços de ~6 MB (a mensagem única de um vídeo grande passa do limite do Chrome) e com até 3 tentativas.
      let lastError = "";
      for (let attempt = 1; attempt <= 3; attempt += 1) {
        const reply = await sendInParts(job.file, buffer);
        if (reply && reply.ok) { state.cloud[job.key] = "ok"; return true; }
        lastError = (reply && reply.error) || "sem resposta da extensão";
        await new Promise((r) => setTimeout(r, 1500 * attempt));
      }
      throw new Error(lastError);
    } catch (e) {
      state.cloud[job.key] = "fail";
      state.cloudWhy = { ...(state.cloudWhy || {}), [job.key]: String((e && e.message) || e).slice(0, 80) };
      setNow(`Não consegui enviar ${job.file} pela página (${(e && e.message) || e}). Tento pelo download.`);
      return false;
    }
  }

  async function downloadTile(tile, filename, upload) {
    const img = tile.img;
    img.click();
    const dl = await waitFor(() => $$("button").find((b) => visible(b) && text(b) === "download"), 10000);
    if (!dl) throw new Error("Não achei o botão de baixar do Flow.");
    await nameNextDownload(filename, upload);
    dl.click();
    const item = await waitFor(() => $$("[role=menuitem], .mat-mdc-menu-item", overlay()).filter(visible).find((i) => /^720p/i.test(text(i))) || null, 5000);
    const fallback = $$("[role=menuitem], .mat-mdc-menu-item", overlay()).filter(visible)[1];
    (item || fallback || {}).click?.();
    await sleep(2500);
    const back = $$("button").find((b) => visible(b) && text(b) === "arrow_back");
    if (back) back.click(); else history.back();
    await waitFor(() => editor() && visible(editor()), 10000);
    await sleep(800);
  }

  /* ---------- painel ---------- */
  const css = `
  :host{all:initial}
  *{box-sizing:border-box}
  .box{position:fixed;top:72px;right:16px;width:372px;max-height:calc(100vh - 100px);overflow:auto;z-index:2147483000;color:#f2eefc;font:13px/1.45 "Google Sans",Inter,system-ui,sans-serif;border-radius:22px;padding:1px;
    background:linear-gradient(160deg,rgba(169,139,255,.7),rgba(123,63,228,.15) 35%,rgba(70,40,160,.1) 70%,rgba(169,139,255,.5));box-shadow:0 0 0 1px rgba(0,0,0,.4),0 24px 70px rgba(80,30,200,.45),0 0 40px rgba(123,63,228,.25)}
  .inner{border-radius:21px;background:radial-gradient(120% 80% at 100% 0%,rgba(123,63,228,.28),transparent 55%),radial-gradient(90% 60% at 0% 100%,rgba(58,155,187,.12),transparent 60%),#0a0814;overflow:hidden}
  .head{display:flex;align-items:center;gap:10px;padding:14px 16px;border-bottom:1px solid rgba(255,255,255,.07)}
  .orb{width:30px;height:30px;border-radius:50%;flex:none;background:conic-gradient(from 0deg,#7b3fe4,#a98bff,#3a9bbb,#7b3fe4);animation:spin 5s linear infinite;position:relative;box-shadow:0 0 18px rgba(123,63,228,.7)}
  .orb:after{content:"";position:absolute;inset:5px;border-radius:50%;background:#0a0814}
  .idle .orb{animation-duration:4s}
  .run .orb{animation-duration:1.3s}
  .ring{position:fixed;z-index:2147482999;pointer-events:none;border-radius:14px;border:3px solid #a98bff;box-shadow:0 0 0 4px rgba(123,63,228,.35),0 0 28px 6px rgba(169,139,255,.6);animation:ringpulse 1.2s ease-in-out infinite}
  .ring[hidden]{display:none}
  button.b.pulse{animation:gopulse 1.2s ease-in-out infinite}
  .ttl{flex:1;min-width:0}
  .eyebrow{font:600 9px ui-monospace,SFMono-Regular,monospace;letter-spacing:.18em;color:#a98bff;text-transform:uppercase}
  .title{font-weight:700;font-size:15px;letter-spacing:-.01em}
  .x{background:rgba(255,255,255,.06);border:0;color:#c9bbfa;cursor:pointer;font-size:15px;width:26px;height:26px;border-radius:50%}
  .x:hover{background:rgba(255,255,255,.12)}
  .body{padding:14px 16px 16px;display:flex;flex-direction:column;gap:12px}
  .chips{display:flex;gap:6px;flex-wrap:wrap}
  .chip{font:600 10px ui-monospace,monospace;letter-spacing:.06em;padding:4px 9px;border-radius:99px;border:1px solid rgba(169,139,255,.35);color:#c9bbfa;background:rgba(123,63,228,.12);display:inline-flex;align-items:center;gap:6px}
  .dot{width:6px;height:6px;border-radius:50%;background:#5bd69a;box-shadow:0 0 8px #5bd69a}
  .run .dot{background:#f5b454;box-shadow:0 0 8px #f5b454;animation:pulse 1.1s ease-in-out infinite}
  .status{border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.03);border-radius:16px;padding:12px 14px}
  .now{font-size:13px;color:#f2eefc}
  .muted{font-size:11px;color:#a79fb8}
  .err{font-size:12px;color:#ff7a95;margin-top:6px}
  .err:empty{display:none}
  .bar{height:6px;border-radius:99px;background:rgba(255,255,255,.08);overflow:hidden;margin-top:10px;position:relative}
  .bar>i{display:block;height:100%;width:0;border-radius:99px;background:linear-gradient(90deg,#5a1baa,#7b3fe4,#a98bff);box-shadow:0 0 14px #7b3fe4;transition:width .5s}
  .steps{display:flex;gap:6px;margin-bottom:10px}
  .stp{flex:1;display:flex;align-items:center;gap:6px;padding:6px 8px;border-radius:12px;border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.03);font:600 10px ui-monospace,monospace;letter-spacing:.05em;text-transform:uppercase;color:#8d85a3;position:relative;overflow:hidden}
  .stp i{width:16px;height:16px;border-radius:50%;flex:none;border:2px solid rgba(255,255,255,.18);display:grid;place-items:center;font-style:normal;font-size:9px}
  .stp.on{color:#fff;border-color:rgba(245,180,84,.6);background:rgba(245,180,84,.08)}
  .stp.on i{border:2px solid transparent;border-top-color:#f5b454;border-right-color:#f5b454;animation:spin .9s linear infinite}
  .stp.on:after{content:"";position:absolute;inset:0;background:linear-gradient(90deg,transparent,rgba(255,255,255,.12),transparent);animation:scan 1.8s linear infinite}
  .stp.ok{color:#5bd69a;border-color:rgba(91,214,154,.35)}
  .stp.ok i{border-color:#5bd69a;background:#5bd69a;color:#0a0814}
  .doing{font-weight:700;font-size:14px;margin-bottom:2px}
  .pbar{height:8px;border-radius:99px;background:rgba(255,255,255,.08);overflow:hidden;width:100%}
  .pbar i{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,#8B5CF6,#A98BFF);transition:width .8s ease}
  .plabel{display:flex;justify-content:space-between;width:100%;margin-top:6px}
  .clock{font:600 11px ui-monospace,monospace;color:#c9bbfa;margin-top:8px;display:flex;gap:10px;flex-wrap:wrap}
  .clock span{padding:3px 8px;border-radius:99px;background:rgba(123,63,228,.14);border:1px solid rgba(169,139,255,.25)}
  .run .bar:after{content:"";position:absolute;inset:0;background:linear-gradient(90deg,transparent,rgba(255,255,255,.35),transparent);animation:scan 1.6s linear infinite}
  .row{display:flex;gap:8px;flex-wrap:wrap}
  button.b{border:0;border-radius:99px;padding:10px 18px;font:600 12px inherit;cursor:pointer;color:#fff;background:linear-gradient(135deg,#8b5cf6,#7b3fe4);box-shadow:0 8px 22px -8px #7b3fe4}
  button.b:hover:not(:disabled){filter:brightness(1.12)}
  button.b.o{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.16);color:#e8e2f8;box-shadow:none}
  button.b:disabled{opacity:.4;cursor:default}
  details.adv{border:1px dashed rgba(255,255,255,.14);border-radius:14px;padding:9px 12px}
  details.adv summary{cursor:pointer;font:600 10px ui-monospace,monospace;letter-spacing:.12em;color:#a79fb8;text-transform:uppercase}
  textarea{width:100%;min-height:76px;resize:vertical;margin-top:10px;background:#07060d;color:#d9d2ee;border:1px solid rgba(255,255,255,.12);border-radius:12px;padding:8px;font:11px ui-monospace,monospace}
  ul{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:5px;max-height:210px;overflow:auto}
  li{display:flex;align-items:center;justify-content:space-between;gap:8px;font-size:12px;padding:8px 11px;border-radius:12px;background:rgba(255,255,255,.035);border:1px solid rgba(255,255,255,.05)}
  li.cur{border-color:rgba(245,180,84,.45);background:rgba(245,180,84,.07)}
  li span:last-child{font:600 10px ui-monospace,monospace;letter-spacing:.06em;text-transform:uppercase}
  .st-done{color:#5bd69a}.st-run{color:#f5b454}.st-err{color:#ff7a95}.st-wait{color:#8d85a3}
  label.chk{display:flex;gap:6px;align-items:center;font-size:11px;color:#c9bbfa;margin-top:10px}
  @keyframes spin{to{transform:rotate(360deg)}}
  @keyframes pulse{50%{opacity:.35}}
  @keyframes ringpulse{50%{opacity:.45;transform:scale(1.04)}}
  @keyframes gopulse{50%{box-shadow:0 0 0 6px rgba(139,92,246,.35),0 8px 22px -8px #7b3fe4}}
  @keyframes scan{from{transform:translateX(-100%)}to{transform:translateX(100%)}}
  @media (prefers-reduced-motion:reduce){.run .dot,.run .bar:after,.ring,button.b.pulse,.stp.on:after{animation:none}}
  `;

  const host = document.createElement("div");
  host.id = "clipgringa-flow-host";
  document.documentElement.appendChild(host);
  const root = host.attachShadow({ mode: "open" });
  root.innerHTML = `
  <style>${css}</style>
  <div class="ring" id="ring" hidden></div>
  <div class="box idle" id="box"><div class="inner">
    <div class="head"><span class="orb"></span><div class="ttl"><div class="eyebrow">Piloto automático · Flow</div><div class="title">ClipGringa</div></div><button class="x" id="min" title="Minimizar">–</button></div>
    <div class="body" id="body">
      <div class="chips"><span class="chip"><i class="dot"></i><span id="chipst">PRONTO</span></span><span class="chip" id="chipmodel">LOWER PRIORITY · 0 CRÉDITOS</span></div>
      <div class="status">
        <div class="steps" id="steps" hidden>
          <div class="stp" data-p="imagem"><i>1</i>Imagem</div><div class="stp" data-p="vídeo"><i>2</i>Animar</div><div class="stp" data-p="enviando"><i>3</i>Enviar</div><div class="stp" data-p="baixando"><i>4</i>Baixar</div>
        </div>
        <div class="doing" id="doing"></div>
        <div class="now" id="now">Pronto. Envie o pacote pelo site e eu faço o resto sozinho.</div>
        <div class="err" id="err"></div>
        <div class="bar"><i id="fill"></i></div>
        <div class="clock" id="clock" hidden></div>
      </div>
      <ul id="list"></ul>
      <div class="row"><button class="b" id="go">Começar</button><button class="b o" id="stop" disabled>Parar</button><button class="b o" id="clear">Limpar</button></div>
      <details class="adv"><summary>Pacote (avançado)</summary>
        <textarea id="pkg" placeholder='Cole aqui o pacote do ClipGringa'></textarea>
        <label class="chk"><input type="checkbox" id="fast" checked> Uma cena de cada vez (cria 1 imagem e anima essa imagem)</label>
        <label class="chk"><input type="checkbox" id="test"> Só a primeira cena (teste)</label>
      </details>
    </div>
  </div></div>`;

  const el = (id) => root.getElementById(id);
  let running = false;
  let stopFlag = false;
  let state = { jobs: [], done: {}, errors: {}, cloud: {} };
  let uploadInfo = null; // destino no ClipGringa (token curto enviado pelo site junto com o pacote)

  let nowText = "";
  function setNow(msg) { nowText = msg; el("now").textContent = msg; publish(); }
  // Conta o andamento ao site do ClipGringa (barra de progresso, tempo de cada vídeo, o que está fazendo).
  const PROGRESS_KEY = "clipgringa-flow-progress-v1";
  const IMAGES_KEY = "clipgringa-flow-images-v1";
  let limitState = null; // aviso de limite do Flow em andamento (publicado ao site)
  const jobPct = {}; // porcentagem em andamento de cada cena (só na memória)
  let lastPublish = 0;
  function publish(force) {
    if (!force && Date.now() - lastPublish < 800) return;
    lastPublish = Date.now();
    try {
      const jobs = state.jobs || [];
      const cur = jobs.find((j) => j.key === state.current);
      chrome.storage.local.set({ [PROGRESS_KEY]: {
        at: Date.now(), running: !!running, total: jobs.length,
        done: jobs.filter((j) => state.done[j.key]).length,
        errors: Object.keys(state.errors || {}).length,
        phase: state.phase || "", now: nowText, limit: limitState,
        current: cur ? { vi: cur.vi, si: cur.si } : null,
        startedAt: runAt || 0, jobStartedAt: jobAt || 0,
        dur: state.dur || {},
        jobs: jobs.map((j) => ({ key: j.key, vi: j.vi, si: j.si, vname: j.vname, sname: j.sname, vbase: j.vbase, sbase: j.sbase, file: j.file, done: !!state.done[j.key], error: state.errors[j.key] || "", pct: typeof jobPct[j.key] === "number" ? jobPct[j.key] : null })),
      } });
    } catch (_e) { /* extensão recarregada */ }
  }
  window.setInterval(() => publish(true), 2000);
  function setRunning(on) {
    const box = el("box"); box.classList.toggle("run", on); box.classList.toggle("idle", !on);
    el("chipst").textContent = on ? "TRABALHANDO" : "PRONTO";
  }
  function setError(msg) { el("err").textContent = msg || ""; }

  /* ---------- etapa atual, tempo e previsão ---------- */
  const PHASES = ["imagem", "vídeo", "enviando", "baixando"];
  const DOING = {
    "imagem": "Etapa 1 de 4 · Gerando a imagem da cena",
    "vídeo": "Etapa 2 de 4 · Animando a imagem em vídeo",
    "enviando": "Etapa 3 de 4 · Enviando o vídeo para o ClipGringa",
    "baixando": "Etapa 4 de 4 · Baixando o vídeo",
  };
  let phaseAt = 0; let jobAt = 0; let runAt = 0;
  const fmt = (sec) => { sec = Math.max(0, Math.round(sec)); return `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, "0")}`; };
  const fmtMin = (sec) => (sec < 90 ? "menos de 2 min" : `~${Math.round(sec / 60)} min`);
  function setPhase(name) {
    state.phase = name; phaseAt = Date.now();
    el("doing").textContent = DOING[name] || "";
    tickClock(); render();
  }
  function avgJobSeconds() {
    const values = Object.values(state.dur || {}).filter((v) => v > 0);
    return values.length ? values.reduce((a, b) => a + b, 0) / values.length : 240; // sem histórico: ~4 min por cena
  }
  function tickClock() {
    const steps = el("steps"); const clock = el("clock");
    const on = running && state.phase;
    steps.hidden = !on; clock.hidden = !on;
    if (!on) { el("doing").textContent = ""; return; }
    const idx = PHASES.indexOf(state.phase);
    steps.querySelectorAll(".stp").forEach((node, i) => { node.classList.toggle("on", i === idx); node.classList.toggle("ok", i < idx); const dot = node.querySelector("i"); dot.textContent = i < idx ? "✓" : String(i + 1); });
    const left = state.jobs.filter((j) => !state.done[j.key]).length;
    const avg = avgJobSeconds();
    const thisJob = (Date.now() - jobAt) / 1000;
    const remaining = Math.max(0, left - 1) * avg + Math.max(30, avg - thisJob);
    const total = state.jobs.length || 1;
    const doneN = total - left;
    const within = Math.min(0.95, Math.max(0, (idx + 0.5) / PHASES.length));
    const pct = Math.min(99, Math.round(((doneN + within) / total) * 100));
    const nth = Math.min(total, doneN + 1);
    clock.innerHTML = `<div class="pbar"><i style="width:${pct}%"></i></div><div class="plabel"><span>Cena ${nth} de ${total}</span><span>${pct}%</span></div>`;
  }
  window.setInterval(() => { if (running) tickClock(); }, 1000);

  function render() {
    const total = state.jobs.length;
    const done = state.jobs.filter((j) => state.done[j.key]).length;
    el("fill").style.width = total ? `${Math.round((done / total) * 100)}%` : "0";
    el("list").innerHTML = state.jobs.map((j) => {
      const label = `${j.vname} · ${j.sname}`;
      let st = "<span class='st-wait'>na fila</span>";
      if (state.done[j.key]) st = `<span class='st-done'>baixado${state.cloud[j.key] === "ok" ? " · no ClipGringa" : state.cloud[j.key] ? ` · não enviado${state.cloudWhy && state.cloudWhy[j.key] ? ` (${state.cloudWhy[j.key].replace(/[<>&]/g, "")})` : ""}` : ""}</span>`;
      else if (state.errors[j.key]) { const why = String(state.errors[j.key]).replace(/[<>&"]/g, "").slice(0, 160); st = `<span class='st-err' title="${why}">erro · ${why.slice(0, 55)}${why.length > 55 ? "…" : ""}</span>`; }
      else if (state.current === j.key) st = `<span class='st-run'>${state.phase || "gerando"}</span>`;
      return `<li class="${state.current === j.key ? "cur" : ""}"><span>${label}</span>${st}</li>`;
    }).join("");
  }

  let autoRun = false;
  async function persist() {
    await storage.set({ jobs: state.jobs, done: state.done, errors: state.errors, cloud: state.cloud, dur: state.dur || {}, upload: uploadInfo, raw: el("pkg").value, auto: autoRun });
  }

  /* ---------- limite do Flow: avisa, cronometra e retoma ---------- */
  const LIMIT_RE = /limite|limit|quota|cota|muitas|too many|esperar|aguarde|wait|try again|tente novamente|cr[eé]ditos? (?:insuficientes?|esgotados?)|(?:n[aã]o (?:tem|h[aá])|sem) cr[eé]ditos?|not enough credits|out of credits/i;
  const isLimited = (msg) => LIMIT_RE.test(String(msg || ""));
  const noCredits = (msg) => /cr[eé]ditos?|credits?/i.test(String(msg)) && /insuficien|esgot|acab|not enough|out of|run out|no (?:more )?credits/i.test(String(msg)) || /(?:n[aã]o (?:tem|h[aá])|sem) cr[eé]ditos?/i.test(String(msg));
  // Lê o tempo que o próprio Flow informou ("tente novamente em 5 minutos", "in 2 hours"…). Sem tempo informado → null.
  function parseWaitSeconds(msg) {
    const t = String(msg || "").toLowerCase();
    let total = 0; let found = false;
    const re = /(\d+(?:[.,]\d+)?)\s*(horas?|hours?|hrs?|h|minutos?|minutes?|mins?|min|segundos?|seconds?|secs?|s)\b/g;
    let m;
    while ((m = re.exec(t))) {
      const n = parseFloat(m[1].replace(",", "."));
      const u = m[2];
      total += /^h/.test(u) ? n * 3600 : /^m/.test(u) ? n * 60 : n;
      found = true;
    }
    return found && total > 0 ? Math.min(Math.round(total), 24 * 3600) : null;
  }
  const LIMIT_RETRY_SECONDS = 120; // sem tempo informado pelo Flow: tenta de novo a cada 2 min
  async function readCredits() {
    try { const a = (await chrome.storage.local.get("clipgringa-flow-account-v1"))["clipgringa-flow-account-v1"]; return a && typeof a.credits === "number" ? a.credits : null; } catch (_e) { return null; }
  }
  async function waitForLimit(label, message) {
    const known = parseWaitSeconds(message);
    const seconds = known ? known + 5 : LIMIT_RETRY_SECONDS;
    const startCredits = await readCredits();
    const since = Date.now();
    let resumeAt = since + seconds * 1000;
    limitState = { since, resumeAt, known: !!known, kind: noCredits(message) ? "credits" : "limit", message: String(message || "").slice(0, 200) };
    publish(true);
    let tick = 0;
    try {
      while (Date.now() < resumeAt) {
        if (stopFlag) throw new Error("STOP");
        const left = Math.max(0, Math.round((resumeAt - Date.now()) / 1000));
        setNow(`${label}: ${known ? "limite do Flow" : "o Flow pediu para esperar"}. Retomando em ${fmt(left)}. Para continuar já, troque de conta no Flow.`);
        tick += 1;
        if (tick % 5 === 0) {
          const now = await readCredits();
          if (now !== null && (startCredits === null ? now > 0 && limitState.kind === "credits" : now > startCredits)) { setNow(`${label}: créditos novos detectados (outra conta?). Continuando…`); break; }
        }
        await sleep(1000);
      }
    } finally { limitState = null; publish(true); }
  }

  async function withRetry(label, fn) {
    let lastError;
    for (let attempt = 0; attempt <= RETRIES; attempt += 1) {
      if (stopFlag) throw new Error("STOP");
      try { return await fn(attempt); } catch (e) {
        lastError = e;
        cfgDone = ""; // qualquer falha: na próxima tentativa os ajustes são conferidos de novo
        if (e.message === "STOP") throw e;
        if (isLimited(e.message)) { await waitForLimit(label, e.message); attempt -= 1; continue; } // limite não gasta tentativas: espera e repete
        if (attempt < RETRIES) {
          const why = `não deu certo (${String(e.message).slice(0, 90)})`;
          for (let s = 3; s > 0; s -= 1) {
            if (stopFlag) throw new Error("STOP");
            setNow(`${label}: ${why}. Tentando de novo em ${s}s (tentativa ${attempt + 2} de ${RETRIES + 1})…`);
            await sleep(1000);
          }
        }
      }
    }
    throw lastError;
  }

  // Anexa a foto real do produto como referência no Flow, para o avatar aparecer apresentando o produto de verdade.
  // Nunca atrapalha: se o Flow não aceitar, segue só com o texto do prompt.
  async function attachReference() {
    if (!productImage || refDone) return;
    refDone = true; // tenta uma vez por pacote; se o Flow guardar a referência, vale para as próximas cenas
    try {
      const blob = await (await fetch(productImage)).blob();
      const file = new File([blob], "produto.jpg", { type: blob.type || "image/jpeg" });
      const findInput = () => $$("input[type=file]", document).find((i) => !i.disabled && /image/i.test(i.accept || "image"));
      let input = findInput();
      if (!input) {
        const add = $$("button", promptBox() ? promptBox().parentElement || document : document).filter(visible)
          .find((b) => /adicionar|add|anexar|upload|enviar imagem|imagem|image/i.test(`${b.getAttribute("aria-label") || ""} ${b.title || ""}`) || ["add", "add_2", "add_photo_alternate", "upload"].some((icon) => hasIcon(b, icon)));
        if (add) { add.click(); await sleep(900); input = findInput(); }
      }
      if (!input) return;
      const transfer = new DataTransfer();
      transfer.items.add(file);
      input.files = transfer.files;
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
      await sleep(3500);
    } catch (_e) { /* segue sem a referência */ }
  }

  async function makeImage(job, label) {
    setPhase("imagem");
    const reuse = sceneImages[job.key] && locateTile(sceneImages[job.key]);
    if (reuse) { setNow(`${label}: reaproveitando a imagem que já foi criada.`); return reuse; }
    const baseline = new Set(tilesNow().map((t) => t.src));
    return withRetry(`${label} (imagem)`, async (attemptNo) => {
      if (attemptNo > 0) {
        // a tentativa anterior pode ter funcionado mesmo dando erro: usa a imagem nova em vez de gastar outra geração
        const stray = tilesNow().find((t) => !baseline.has(t.src) && !claimedTiles.has(t.src));
        if (stray) { setNow(`${label}: a imagem já apareceu no Flow, usando ela.`); return waitNewTile(baseline, "image", IMAGE_WAIT_MS); }
      }
      setNow(`${label}: preparando o Flow para gerar a imagem…`);
      await configure("image");
      await attachReference();
      await setPrompt(job.imagePrompt);
      const before = tileKeys();
      await pressGenerate();
      setNow(`${label}: gerando a imagem (cerca de 15 segundos)…`);
      return waitNewTile(before, "image", IMAGE_WAIT_MS, (p) => { if (p != null) { jobPct[job.key] = p; setNow(`${label}: gerando a imagem… ${p}%`); } });
    }).then(async (image) => { jobPct[job.key] = 100; claimedTiles.add(image.src); sceneImages[job.key] = { src: image.src, tile: image.tile }; await keepImage(job, image); delete jobPct[job.key]; return image; });
  }

  // Guarda uma miniatura da imagem da cena (para o ClipGringa mostrar e deixar baixar). Nunca atrapalha a geração.
  async function keepImage(job, image) {
    try {
      const url = `${baseSrc(image.src)}=s1080`;
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) return;
      const bitmap = await createImageBitmap(await res.blob());
      const scale = Math.min(1, 1080 / Math.max(bitmap.width, bitmap.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(bitmap.width * scale); canvas.height = Math.round(bitmap.height * scale);
      canvas.getContext("2d").drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL("image/jpeg", 0.82);
      const all = (await chrome.storage.local.get(IMAGES_KEY))[IMAGES_KEY] || {};
      all[job.key] = { file: job.file.replace(/\.mp4$/i, ".jpg"), data: dataUrl };
      await chrome.storage.local.set({ [IMAGES_KEY]: all });
      // Guarda também no banco de imagens da conta (somente o dono vê).
      if (uploadInfo) {
        try { await chrome.runtime.sendMessage({ type: "clipgringa-upload", upload: uploadInfo, file: all[job.key].file, b64: dataUrl.split(",")[1] }); } catch (_e) { /* ignora */ }
      }
    } catch (_e) { /* sem miniatura: tudo o resto segue */ }
  }

  async function finishJob(job, video, label) {
    state.current = job.key;
    setPhase("enviando");
    setNow(`${label}: enviando ${job.file} para o ClipGringa…`);
    const sent = await uploadVideo(video, job);
    setPhase("baixando");
    setNow(`${label}: baixando ${job.file}…`);
    await withRetry(`${label} (download)`, () => downloadTile(video, job.file, sent || !uploadInfo ? null : uploadInfo));
    state.done[job.key] = true;
    state.dur = { ...(state.dur || {}), [job.key]: Math.round((Date.now() - jobAt) / 1000) };
    delete state.errors[job.key];
    await persist();
  }

  async function runJob(job, onlyFirst) {
    const label = `${job.vname} · ${job.sname}`;
    state.current = job.key; jobAt = Date.now();

    // 1) imagem (primeiro passo: a imagem da cena)
    const image = await makeImage(job, label);

    // 2) vídeo: anima a imagem aprovada, em Lower Priority
    setPhase("vídeo");
    const video = await withRetry(`${label} (vídeo)`, async (attemptNo) => {
      setNow(isLowerPriority() ? `${label}: escolhendo Veo 3.1 Lite [Lower Priority] (0 créditos)…` : `${label}: escolhendo o modelo ${flowModel} (gasta créditos do Flow)…`);
      await configure("video");
      try { await chooseStartFrame(image.src); } catch (pickErr) {
        // Última tentativa: sem escolher o quadro inicial, o Flow ainda anima pelo texto (a imagem não entra, mas o vídeo sai).
        if (/vi:|Início|Incluir/.test(String(pickErr.message)) && attemptNo >= RETRIES) setNow(`${label}: não consegui escolher a imagem inicial, animando só pelo texto.`);
        else throw pickErr;
      }
      await setPrompt(job.videoPrompt);
      const before = tileKeys();
      await pressGenerate();
      setNow(`${label}: o Flow está animando${isLowerPriority() ? " em Lower Priority" : ""}. Pode levar de 1 a 6 minutos, não feche esta aba.`);
      return waitNewTile(before, "video", VIDEO_WAIT_MS, (p) => { if (p != null) { jobPct[job.key] = p; setNow(`${label}: animando${isLowerPriority() ? " em Lower Priority" : ""}… ${p}%`); } });
    });

    // 3) enviar para o ClipGringa e 4) baixar
    await finishJob(job, video, label);
    if (onlyFirst) stopFlag = true;
  }

  /* ---------- modo rápido (BETA): o Flow anima várias cenas ao mesmo tempo ---------- */
  const VIDEO_PARALLEL = 1;
  const IMAGE_PARALLEL = 1;
  const tilesNow = () => firstTiles(40);
  const generatingNow = (info) => /\d+\s*%/.test(info) || /gerando|generating/i.test(info);
  const labelOf = (job) => `${job.vname} · ${job.sname}`;

  function locateTile(rec) {
    if (rec.tile && rec.tile.isConnected) {
      const img = rec.tile.querySelector("img");
      if (img) return { src: baseSrc(img.src), img, tile: rec.tile, info: rec.tile.innerText || "" };
    }
    return tilesNow().find((t) => t.src === rec.src) || null;
  }

  // Manda animar uma cena e volta assim que o Flow começa (sem esperar o vídeo ficar pronto).
  async function submitVideo(job, image, label, attemptNo) {
    setPhase("vídeo");
    if (!baselines.has("V" + job.key)) baselines.set("V" + job.key, new Set(tilesNow().map((t) => t.src)));
    if (attemptNo > 0) {
      const stray = tilesNow().find((t) => !baselines.get("V" + job.key).has(t.src) && !claimedTiles.has(t.src));
      if (stray) { claimedTiles.add(stray.src); return { src: stray.src, tile: stray.tile, t0: Date.now() }; }
    }
    setNow(`${label}: mandando animar a imagem…`);
    await configure("video");
    if (roundNo >= 2) setNow(`${label}: último recurso, animando só pelo texto…`);
    else try { await chooseStartFrame(image.src, true); } catch (pickErr) {
      if (/vi:|Início|Incluir/.test(String(pickErr.message)) && attemptNo >= RETRIES) setNow(`${label}: não consegui escolher a imagem inicial, animando só pelo texto.`);
      else throw pickErr;
    }
    await setPrompt(job.videoPrompt);
    const known = new Set(tilesNow().map((t) => t.src));
    const count0 = known.size;
    await pressGenerate();
    const appeared = await waitFor(() => { const now = tilesNow(); return now.length > count0 ? now.find((t) => !known.has(t.src)) || null : null; }, roundNo >= 1 ? 60000 : 30000, 700);
    if (!appeared) throw new Error("O Flow não começou a animar esta cena.");
    claimedTiles.add(appeared.src);
    return { src: appeared.src, tile: appeared.tile, t0: Date.now() };
  }

  function failJob(job, message) {
    state.errors[job.key] = message;
    setError(`${labelOf(job)}: ${message}`);
  }

  // Manda criar a imagem de uma cena e volta assim que o Flow começa (as outras imagens seguem em paralelo).
  async function submitImage(job, label, attemptNo) {
    setPhase("imagem");
    if (!baselines.has("I" + job.key)) baselines.set("I" + job.key, new Set(tilesNow().map((t) => t.src)));
    if (attemptNo > 0) {
      const stray = tilesNow().find((t) => !baselines.get("I" + job.key).has(t.src) && !claimedTiles.has(t.src));
      if (stray) { claimedTiles.add(stray.src); return { src: stray.src, tile: stray.tile, t0: Date.now() }; }
    }
    setNow(`${label}: mandando criar a imagem…`);
    await configure("image");
    await attachReference();
    await setPrompt(job.imagePrompt);
    const known = new Set(tilesNow().map((t) => t.src));
    const count0 = known.size;
    await pressGenerate();
    const appeared = await waitFor(() => { const now = tilesNow(); return now.length > count0 ? now.find((t) => !known.has(t.src)) || null : null; }, 30000, 500);
    if (!appeared) throw new Error("O Flow não começou a criar esta imagem.");
    claimedTiles.add(appeared.src);
    return { src: appeared.src, tile: appeared.tile, t0: Date.now() };
  }

  /** Acompanha as cenas em andamento. Volta quando ao menos uma termina (`any`) ou quando todas terminam. Devolve as que continuam. */
  async function collectActive(active, { kind, timeoutMs, onDone, any, peek }) {
    const waiting = new Map(active.map((b) => [b.job.key, { ...b, since: Date.now() }]));
    const total = waiting.size;
    while (waiting.size) {
      if (stopFlag) throw new Error("STOP");
      const pcts = [];
      for (const [key, b] of Array.from(waiting)) {
        const t = locateTile(b.rec);
        if (!t) { if (Date.now() - b.since > 90000) { failJob(b.job, "não achei esta cena na grade do Flow"); waiting.delete(key); } continue; }
        b.since = Date.now();
        if (isFailed(t.info)) { failJob(b.job, failReason(t.info)); waiting.delete(key); continue; }
        const done = !generatingNow(t.info) && (kind === "image" || /play_circle|videocam|movie/.test(t.info) || t.tile.querySelector("video"));
        if (done) {
          waiting.delete(key);
          jobAt = b.rec.t0;
          try { await onDone(b, t); } catch (e) { if (e.message === "STOP") throw e; failJob(b.job, e.message); }
          await persist(); render();
        } else {
          const pct = (t.info.match(/(\d+)\s*%/) || [])[1]; if (pct) jobPct[key] = Number(pct);
          pcts.push(`${labelOf(b.job)} ${pct ? pct + "%" : "na fila"}`);
          if (Date.now() - b.rec.t0 > timeoutMs) { failJob(b.job, "O Flow demorou demais para terminar."); waiting.delete(key); }
        }
      }
      if (pcts.length) setNow(`${kind === "image" ? "Criando" : "Animando"} ${pcts.length} cena(s) ao mesmo tempo no Flow: ${pcts.join(" · ")}`);
      if (peek || (any && waiting.size < total)) break;
      await sleep(kind === "image" ? 800 : 1500);
    }
    return Array.from(waiting.values()).map(({ job, rec }) => ({ job, rec }));
  }

  // Fila contínua: assim que uma cena termina, a próxima já é enviada (sem esperar o grupo inteiro).
  async function rollingStage({ jobs, parallel, kind, submit, timeoutMs, onDone }) {
    let next = 0;
    let active = [];
    while ((next < jobs.length || active.length) && !stopFlag) {
      while (next < jobs.length && active.length < parallel && !stopFlag) {
        const job = jobs[next++];
        state.current = job.key; render();
        try {
          const rec = await withRetry(`${labelOf(job)} (${kind === "image" ? "imagem" : "vídeo"})`, (attemptNo) => submit(job, attemptNo));
          active.push({ job, rec });
        } catch (e) { if (e.message === "STOP") { stopFlag = true; return; } failJob(job, e.message); await persist(); render(); }
        // dá uma olhada no que já terminou entre um envio e outro
        if (active.length) active = await collectActive(active, { kind, timeoutMs, onDone, any: true, peek: true }).catch((e) => { if (e.message === "STOP") throw e; return active; });
      }
      if (!active.length) continue;
      try { active = await collectActive(active, { kind, timeoutMs, onDone, any: true }); } catch (e) { if (e.message === "STOP") { stopFlag = true; return; } throw e; }
    }
  }

  async function runPipeline() {
    const jobs = state.jobs.filter((j) => !state.done[j.key]);
    const images = {};
    // Uma cena de cada vez: cria 1 imagem, anima essa imagem e só então passa para a próxima.
    for (const job of jobs) {
      if (stopFlag) return;
      const kept = sceneImages[job.key] && locateTile(sceneImages[job.key]);
      if (kept) images[job.key] = kept;
      else {
        await rollingStage({
          jobs: [job], parallel: 1, kind: "image", timeoutMs: IMAGE_WAIT_MS,
          submit: (j, attemptNo) => submitImage(j, labelOf(j), attemptNo),
          onDone: async (b, t) => { images[b.job.key] = t; sceneImages[b.job.key] = { src: t.src, tile: t.tile }; jobPct[b.job.key] = 100; await keepImage(b.job, t); delete jobPct[b.job.key]; },
        });
      }
      if (stopFlag) return;
      if (!images[job.key]) continue; // a imagem falhou: segue para a próxima cena (a segunda rodada tenta de novo)
      await rollingStage({
        jobs: [job], parallel: 1, kind: "video", timeoutMs: VIDEO_WAIT_MS,
        submit: (j, attemptNo) => submitVideo(j, images[j.key], labelOf(j), attemptNo),
        onDone: async (b, t) => { await finishJob(b.job, t, labelOf(b.job)); },
      });
    }
  }

  const FLOW_HOME = "https://labs.google/fx/pt/tools/flow";
  // Só conta como projeto a tela do projeto em si (não páginas antigas como /project/…/tool/…, que dão "App não encontrada").
  const inProject = () => /\/project\/[^/]+\/?$/.test(location.pathname);

  const isNewProject = (b) => visible(b) && /(novo projeto|new project)/i.test(`${text(b)} ${b.getAttribute("aria-label") || ""}`.trim());

  // Garante que estamos dentro de um projeto do Flow: abre um novo sozinho quando preciso.
  async function ensureProject() {
    if (inProject()) return true;
    setNow("Abrindo um novo projeto no Flow…");
    const btn = await waitFor(() => $$("button, [role=button], a", document).find(isNewProject), 15000);
    if (!btn) {
      if (!/\/tools\/flow/.test(location.pathname)) { setNow("Indo para a página do Flow…"); location.href = FLOW_HOME; }
      return false;
    }
    btn.click();
    const inside = await waitFor(inProject, 25000, 300);
    if (inside) await sleep(3000);
    return Boolean(inside);
  }

  async function start() {
    if (running) return;
    setError("");
    if (!(await ensureProject())) {
      setError("Ainda não consegui abrir um projeto sozinho. Se a página recarregar, eu continuo; senão, abra um projeto do Flow.");
      return;
    }
    try {
      // Usa o primeiro pacote que for válido: o do painel, o já carregado, o pendente do site ou o último enviado (até 6 horas).
      let raw = "";
      let badReason = "";
      const findPackage = async () => {
        const pending = (await chrome.storage.local.get(PENDING_KEY))[PENDING_KEY];
        const last = (await chrome.storage.local.get("clipgringa-flow-last-v1"))["clipgringa-flow-last-v1"];
        const options = [
          { text: el("pkg").value.trim() },
          { text: state.raw || "" },
          { text: pending && pending.raw ? pending.raw.trim() : "", upload: pending && pending.upload },
          { text: last && last.raw && Date.now() - last.at < 6 * 3600 * 1000 ? last.raw.trim() : "", upload: last && last.upload },
        ];
        for (const o of options) {
          if (!o.text) continue;
          try { parsePackage(o.text); return o; } catch (e) { badReason = badReason || (e && e.message) || "pacote inválido"; }
        }
        return null;
      };
      let found = await findPackage();
      if (!found) {
        // Sem pacote: pede à aba do ClipGringa para mandar de novo e espera um pouco.
        setNow("Procurando o pacote no ClipGringa…");
        try { await new Promise((res) => chrome.runtime.sendMessage({ type: "clipgringa-request-package" }, () => { void chrome.runtime.lastError; res(); })); } catch (_e) { /* sem resposta */ }
        for (let i = 0; i < 8 && !found; i += 1) { await sleep(800); found = await findPackage(); }
      }
      if (found) { raw = found.text; if (found.upload) uploadInfo = found.upload; el("pkg").value = raw; }
      if (!raw && badReason) throw new Error(`O pacote que chegou está com problema (${badReason}) Volte ao ClipGringa, gere de novo e clique em “Enviar para o Flow”.`);
      if (!raw) {
        // Nenhum projeto chegou: leva a pessoa ao Vídeo orgânico do ClipGringa para subir o vídeo ou a foto do produto.
        try { chrome.runtime.sendMessage({ type: "clipgringa-open-app", path: "/automacao" }, () => { void chrome.runtime.lastError; }); } catch (_e) { /* sem resposta */ }
        throw new Error("Ainda não tem nenhum projeto aqui. Abri o ClipGringa em “Vídeo orgânico”: suba o vídeo ou a foto do produto, espere chegar em “Tudo pronto” e clique em “Enviar para o Flow”. Depois volte a esta aba e clique em Começar.");
      }
      parsePackage(raw); // define o modelo pedido pelo pacote
      if (!state.jobs.length || raw !== (state.raw || "")) {
        const parsed = parsePackage(raw);
        state = { jobs: parsed.jobs, done: {}, errors: {}, cloud: {}, raw }; Object.keys(sceneImages).forEach((k) => delete sceneImages[k]); claimedTiles.clear(); baselines.clear();
        try { chrome.storage.local.remove(IMAGES_KEY); } catch (_e) { /* ignora */ }
        el("pkg").value = raw;
      }
    } catch (e) { setError(e.message); return; }
    running = true; autoRun = true; stopFlag = false; runAt = Date.now(); setRunning(true);
    el("go").disabled = true; el("stop").disabled = false;
    const onlyFirst = el("test").checked;
    await persist(); render();
    try {
      // Três rodadas: cenas que falharam são tentadas de novo sozinhas, sem você clicar (a 3ª muda a forma: anima só pelo texto e espera mais).
      for (let round = 0; round < 3 && !stopFlag; round += 1) {
        roundNo = round;
        if (round >= 1) {
          const pending = state.jobs.filter((j) => !state.done[j.key]);
          if (!pending.length) break;
          setNow(`Tentando de novo ${pending.length} cena(s) que não saíram ${round === 1 ? "na primeira rodada" : "(último recurso, de outro jeito)"}…`);
          setError("");
        }
        if (round === 0 && !onlyFirst && el("fast").checked && state.jobs.filter((j) => !state.done[j.key]).length > 1) {
          try { await runPipeline(); } catch (e) { if (e.message === "STOP") stopFlag = true; else setError(`Modo rápido: ${e.message}. Vou tentar cena por cena.`); }
          render();
          continue;
        }
        for (const job of state.jobs) {
          if (state.done[job.key]) continue;
          if (stopFlag) break;
          try { await runJob(job, onlyFirst); } catch (e) {
            if (e.message === "STOP") { stopFlag = true; break; }
            state.errors[job.key] = e.message;
            setError(`${`${job.vname} · ${job.sname}`}: ${e.message}`);
            await persist();
          }
          render();
        }
        if (onlyFirst) break;
      }
      const left = state.jobs.filter((j) => !state.done[j.key]).length;
      state.current = null; state.phase = ""; if (!left || stopFlag) autoRun = false; await persist();
      setNow(left === 0 ? `Tudo pronto em ${fmt((Date.now() - runAt) / 1000)}! Os vídeos foram baixados na pasta Downloads/ClipGringa e enviados ao ClipGringa.` : stopFlag ? "Parado. Clique em Começar para continuar de onde parou." : `Terminou com ${left} cena(s) pendente(s). Clique em Começar para tentar de novo.`);
    } finally {
      running = false; setRunning(false); window.setTimeout(() => takePending(), 500); el("go").disabled = false; el("stop").disabled = true; state.phase = ""; tickClock(); render();
    }
  }

  el("go").addEventListener("click", start);
  let pasteTimer = 0;
  el("pkg").addEventListener("input", () => {
    // Colou o pacote? Começa sozinho, sem precisar clicar.
    window.clearTimeout(pasteTimer);
    pasteTimer = window.setTimeout(() => { try { parsePackage(el("pkg").value); if (!running) start(); } catch (_e) { /* ainda não é um pacote válido */ } }, 800);
  });
  el("stop").addEventListener("click", () => { stopFlag = true; autoRun = false; setNow("Cancelando tudo…"); });
  el("clear").addEventListener("click", async () => {
    if (running) return;
    state = { jobs: [], done: {}, errors: {}, cloud: {} };
    el("pkg").value = ""; setError(""); setNow("Pronto para começar."); render(); await storage.set(null);
  });
  el("min").addEventListener("click", () => {
    const body = el("body"); const hidden = body.style.display === "none";
    body.style.display = hidden ? "flex" : "none"; el("min").textContent = hidden ? "–" : "+";
  });

  // Guia: com o pacote salvo, pede para clicar em "Novo projeto"; ao detectar o projeto aberto, mostra o Começar.
  let lastGuide = "";
  function placeRing(target) {
    const ring = el("ring");
    if (!target) { ring.hidden = true; return; }
    const r = target.getBoundingClientRect();
    Object.assign(ring.style, { left: `${r.left - 4}px`, top: `${r.top - 4}px`, width: `${r.width + 8}px`, height: `${r.height + 8}px` });
    ring.hidden = false;
  }
  function updateGuide() {
    if (running) { placeRing(null); el("go").style.display = ""; el("go").classList.remove("pulse"); return; }
    const left = state.jobs.filter((j) => !state.done[j.key]).length;
    if (!state.jobs.length || !left) { placeRing(null); el("go").style.display = ""; el("go").classList.remove("pulse"); return; }
    const inside = inProject() && editor() && visible(editor());
    if (!inside) {
      el("go").style.display = "none"; el("go").classList.remove("pulse");
      placeRing($$("button, [role=button], a", document).find(isNewProject) || null);
      if (lastGuide !== "new") { lastGuide = "new"; setNow("Pacote salvo. Passo 1: clique em “Novo projeto” aqui no Flow. Quando o projeto abrir, aparece o botão Começar."); }
      return;
    }
    placeRing(null); el("go").style.display = ""; el("go").classList.add("pulse");
    if (lastGuide !== "start") { lastGuide = "start"; setNow("Projeto aberto! Agora clique em Começar."); }
  }
  window.setInterval(updateGuide, 600);

  // Pacote enviado direto pelo site: fica salvo no painel; o guia leva até o Começar.
  const PENDING_KEY = "clipgringa-flow-pending-v1";
  async function takePending() {
    try {
      if (running) return;
      const got = (await chrome.storage.local.get(PENDING_KEY))[PENDING_KEY];
      if (!got || !got.raw || Date.now() - got.at > 30 * 60 * 1000) { if (got) await chrome.storage.local.remove(PENDING_KEY); return; }
      // O pacote fica salvo na hora (sobrevive a recarregar a página); quem começa é o botão Começar.
      const parsed = parsePackage(got.raw);
      state = { jobs: parsed.jobs, done: {}, errors: {}, cloud: {}, raw: got.raw.trim() }; Object.keys(sceneImages).forEach((k) => delete sceneImages[k]); claimedTiles.clear(); baselines.clear();
      uploadInfo = got.upload || null;
      el("pkg").value = got.raw;
      await persist();
      await chrome.storage.local.remove(PENDING_KEY);
      setError(""); lastGuide = ""; render(); updateGuide();
      setNow("Pacote recebido do ClipGringa. Começando sozinho…");
      window.setTimeout(() => { if (!running) start(); }, 1500);
    } catch (e) { setError(e && e.message ? e.message : ""); }
  }
  try { chrome.storage.onChanged.addListener((changes) => { if (changes[PENDING_KEY]) takePending(); }); } catch (_e) { /* ignore */ }

  // O site pediu para parar (a pessoa abriu o chat de mudanças): termina de forma limpa e espera o pacote novo.
  try {
    chrome.storage.onChanged.addListener((changes) => {
      const stop = changes["clipgringa-flow-stop-v1"];
      if (!stop || !stop.newValue || Date.now() - stop.newValue.at > 15000) return;
      stopFlag = true; autoRun = false;
      persist().catch(() => undefined);
      setNow("Pausado: você abriu o chat de mudanças. Quando aplicar, o pacote novo chega e eu recomeço sozinho.");
    });
  } catch (_e) { /* ignore */ }

  // Resultado do envio feito pelo plano B (download): atualiza o "no ClipGringa" da lista.
  try {
    chrome.storage.onChanged.addListener((changes) => {
      const got = changes["clipgringa-flow-uploads-v1"];
      if (!got || !got.newValue) return;
      for (const job of state.jobs) {
        const r = got.newValue[job.file];
        if (r && Date.now() - r.at < 120000) {
          state.cloud[job.key] = r.ok ? "ok" : "fail";
          if (!r.ok && r.error) state.cloudWhy = { ...(state.cloudWhy || {}), [job.key]: String(r.error).slice(0, 80) };
        }
      }
      persist().catch(() => undefined); render();
    });
  } catch (_e) { /* ignore */ }

  // A pessoa abriu o ClipGringa e quis continuar o projeto que ficou pela metade: retoma de onde parou (as cenas prontas ficam).
  const RESUME_KEY = "clipgringa-flow-resume-v1";
  const DISCARD_KEY = "clipgringa-flow-discard-v1";
  async function takeResume() {
    try {
      const got = (await chrome.storage.local.get(RESUME_KEY))[RESUME_KEY];
      if (!got || Date.now() - got.at > 60000) return;
      await chrome.storage.local.remove(RESUME_KEY);
      if (running || !state.jobs.length || !state.jobs.some((j) => !state.done[j.key])) return;
      stopFlag = false; autoRun = true;
      setNow("Continuando o projeto de onde parou…");
      window.setTimeout(() => { if (!running) start(); }, 2500);
    } catch (_e) { /* extensão recarregada */ }
  }
  try { chrome.storage.onChanged.addListener((changes) => { if (changes[RESUME_KEY] && changes[RESUME_KEY].newValue) takeResume(); }); } catch (_e) { /* ignore */ }
  // A pessoa preferiu um projeto novo: para e esquece o antigo.
  try {
    chrome.storage.onChanged.addListener(async (changes) => {
      const got = changes[DISCARD_KEY];
      if (!got || !got.newValue || Date.now() - got.newValue.at > 15000) return;
      stopFlag = true; autoRun = false;
      state = { jobs: [], done: {}, errors: {}, cloud: {} };
      el("pkg").value = ""; setError(""); setNow("Pronto para começar."); render();
      try { await storage.set(null); await chrome.storage.local.remove([PROGRESS_KEY, IMAGES_KEY]); } catch (_e) { /* ignora */ }
    });
  } catch (_e) { /* ignore */ }

  window.__clipgringaDebug = { el, start, getState: () => state };

  storage.get().then((saved) => {
    if (saved && saved.jobs && saved.jobs.length) {
      state = { jobs: saved.jobs, done: saved.done || {}, errors: saved.errors || {}, cloud: saved.cloud || {}, dur: saved.dur || {}, raw: (saved.raw || "").trim() };
      uploadInfo = saved.upload || null;
      el("pkg").value = saved.raw || "";
      autoRun = saved.auto === true;
      const left = state.jobs.filter((j) => !state.done[j.key]).length;
      setNow(left ? `Pacote carregado: ${left} cena(s) faltando. Clique em Começar para continuar.` : "Pacote concluído. Clique em Limpar para começar outro.");
      render();
      if (autoRun && left) window.setTimeout(() => { if (!running) start(); }, 2500);
    }
  }).then(takePending).then(takeResume).then(updateGuide);
})();
