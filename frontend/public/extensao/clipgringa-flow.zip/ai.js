/* ClipGringa · Flow — gera texto pela conta de IA da pessoa (Gemini, ChatGPT ou Claude), escrevendo no site como ela faria.
 * Só responde a mensagens da própria extensão. Os seletores de cada site podem mudar; por isso há alternativas e um plano B que lê o texto da página. */
(function () {
  "use strict";
  if (window.__clipgringaAiLoaded) return;
  window.__clipgringaAiLoaded = true;

  const host = location.hostname;
  const SITE = /gemini\.google\.com$/.test(host) ? "gemini" : /(chatgpt\.com|chat\.openai\.com)$/.test(host) ? "chatgpt" : /claude\.ai$/.test(host) ? "claude" : "";
  if (!SITE) return;

  const SEL = {
    gemini: {
      composer: ['rich-textarea .ql-editor', 'div.ql-editor[contenteditable="true"]', 'div[contenteditable="true"][role="textbox"]', 'textarea'],
      send: ['button.send-button', 'button[aria-label*="Enviar"]', 'button[aria-label*="Send message"]', 'button[aria-label*="Send"]'],
      stop: ['button[aria-label*="Parar"]', 'button[aria-label*="Stop"]', 'button[aria-label*="Interromper"]', 'button.send-button.stop', '.stop-icon', 'mat-icon[fonticon="stop"]', 'mat-icon[data-mat-icon-name="stop"]'],
      reply: ['model-response message-content', 'message-content .markdown', '.model-response-text', 'model-response'],
      login: ['a[href*="accounts.google.com/ServiceLogin"]', 'a[href*="accounts.google.com/signin"]'],
    },
    chatgpt: {
      composer: ['#prompt-textarea', 'div.ProseMirror[contenteditable="true"]', 'textarea[name="prompt-textarea"]', 'textarea'],
      send: ['button[data-testid="send-button"]', 'button[aria-label*="Send prompt"]', 'button[aria-label*="Enviar"]', 'button[aria-label*="Send"]'],
      stop: ['button[data-testid="stop-button"]', 'button[aria-label*="Stop"]', 'button[aria-label*="Parar"]'],
      reply: ['[data-message-author-role="assistant"] .markdown', '[data-message-author-role="assistant"]'],
      login: ['[data-testid="login-button"]', 'a[href*="/auth/login"]', 'button[data-testid="welcome-login-button"]'],
    },
    claude: {
      composer: ['div.ProseMirror[contenteditable="true"]', '[data-testid="chat-input"]', 'div[contenteditable="true"]', 'textarea'],
      send: ['button[aria-label*="Send"]', 'button[aria-label*="Enviar"]', 'button[data-testid="send-button"]'],
      stop: ['button[aria-label*="Stop"]', 'button[aria-label*="Parar"]'],
      reply: ['.font-claude-response', '[data-testid="assistant-message"]', '[data-is-streaming]'],
      login: ['a[href*="/login"]', 'button[data-testid="login-button"]'],
    },
  }[SITE];

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const visible = (el) => !!el && (el.offsetParent !== null || el.getClientRects().length > 0);
  const first = (list) => { for (const q of list) { const el = document.querySelector(q); if (el && visible(el)) return el; } return null; };
  const all = (list) => { for (const q of list) { const els = Array.from(document.querySelectorAll(q)).filter(visible); if (els.length) return els; } return []; };

  function challenge() {
    const t = (document.title || "").toLowerCase();
    return /just a moment|um momento|verify you are human|verifique que você é humano/.test(t) || !!document.querySelector("#challenge-form, iframe[src*='challenges.cloudflare.com'], [data-testid='captcha']");
  }

  function state() {
    if (challenge()) return "blocked";
    const composer = first(SEL.composer);
    const loginLink = first(SEL.login);
    if (composer && !loginLink) return "ready";
    if (composer && loginLink) return "guest";
    if (loginLink || /\/(login|signin|auth|ServiceLogin)/i.test(location.pathname + location.href)) return "login";
    return "loading";
  }

  async function waitState(ms) {
    const end = Date.now() + ms;
    let s = state();
    while (Date.now() < end && (s === "loading")) { await sleep(400); s = state(); }
    return s;
  }

  function setText(el, text) {
    el.focus();
    if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
      const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, "value").set.call(el, text);
      el.dispatchEvent(new Event("input", { bubbles: true }));
      return;
    }
    const sel = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(el);
    sel.removeAllRanges();
    sel.addRange(range);
    let ok = false;
    try { ok = document.execCommand("insertText", false, text); } catch (_e) { ok = false; }
    const typed = (el.innerText || el.textContent || "").replace(/\s+/g, "");
    if (!ok || typed.length < Math.floor(text.replace(/\s+/g, "").length * 0.9)) {
      // plano B: colar como texto
      const data = new DataTransfer();
      data.setData("text/plain", text);
      el.focus();
      sel.removeAllRanges();
      sel.addRange(range);
      el.dispatchEvent(new ClipboardEvent("paste", { clipboardData: data, bubbles: true, cancelable: true }));
    }
  }

  function pressEnter(el) {
    const opts = { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true };
    el.dispatchEvent(new KeyboardEvent("keydown", opts));
    el.dispatchEvent(new KeyboardEvent("keypress", opts));
    el.dispatchEvent(new KeyboardEvent("keyup", opts));
  }

  async function send(composer) {
    for (let i = 0; i < 20; i += 1) {
      const btn = first(SEL.send);
      if (btn && !btn.disabled && btn.getAttribute("aria-disabled") !== "true") { btn.click(); return true; }
      await sleep(250);
    }
    pressEnter(composer);
    return true;
  }

  const replyCount = () => all(SEL.reply).length;
  // clipgringaNodeText lê o que está na página, não só o que já foi "revelado": em aba escondida o texto visível fica vazio.
  const lastReply = () => { const els = all(SEL.reply); return els.length ? clipgringaNodeText(els[els.length - 1]) : ""; };

  /** Plano B: texto da página depois do pedido que acabamos de enviar. */
  function afterPrompt(prompt) {
    const body = ((document.querySelector("main") || document.body).innerText || "");
    const marker = prompt.slice(-50).replace(/\s+/g, " ").trim();
    const flat = body.replace(/[ \t]+/g, " ");
    const at = flat.lastIndexOf(marker);
    if (at < 0) return "";
    return flat.slice(at + marker.length).trim();
  }

  /** Cola as imagens no campo do chat (como se a pessoa colasse prints). Devolve quantas o site aceitou. */
  async function attachImages(composer, images) {
    const files = [];
    (images || []).slice(0, 8).forEach((img, i) => {
      try {
        const bin = atob(String(img.data || ""));
        const bytes = new Uint8Array(bin.length);
        for (let k = 0; k < bin.length; k += 1) bytes[k] = bin.charCodeAt(k);
        const mime = /^image\//.test(img.mime) ? img.mime : "image/jpeg";
        files.push(new File([bytes], `quadro-${i + 1}.${mime.split("/")[1].replace("jpeg", "jpg")}`, { type: mime }));
      } catch (_e) { /* imagem inválida: ignora */ }
    });
    if (!files.length) return 0;
    const attached = () => document.querySelectorAll('img[src^="blob:"], [data-testid*="attachment"], [class*="attachment"], uploader-file-preview, [class*="file-preview"], [class*="file-chip"]').length;
    const waitAttached = async (ms) => { for (let i = 0; i < ms / 300 && !attached(); i += 1) await sleep(300); return attached() > 0; };
    const mk = () => { const d = new DataTransfer(); files.forEach((f) => d.items.add(f)); return d; };
    composer.focus();
    // 1) colar no campo (como colar prints)
    composer.dispatchEvent(new ClipboardEvent("paste", { clipboardData: mk(), bubbles: true, cancelable: true }));
    let ok = await waitAttached(2500);
    // 2) campo de arquivo que o site já tem na página (ChatGPT e Claude têm sempre; o Gemini às vezes)
    if (!ok) {
      const input = Array.from(document.querySelectorAll('input[type="file"]')).find((i) => !i.disabled && (!i.accept || /image|\*/.test(i.accept)));
      if (input) {
        try { input.files = mk().files; input.dispatchEvent(new Event("input", { bubbles: true })); input.dispatchEvent(new Event("change", { bubbles: true })); } catch (_e) { /* o site não deixou */ }
        ok = await waitAttached(3000);
      }
    }
    // 3) arrastar para dentro do campo, da área do chat e da página
    if (!ok) {
      const targets = [composer, composer.closest("rich-textarea, .text-input-field, form, [class*=input-area]"), document.querySelector("main, chat-window, .chat-container"), document.body].filter(Boolean);
      for (const target of targets) {
        const drop = mk();
        ["dragenter", "dragover", "drop"].forEach((type) => target.dispatchEvent(new DragEvent(type, { dataTransfer: drop, bubbles: true, cancelable: true })));
        if (await waitAttached(2000)) { ok = true; break; }
      }
    }
    if (ok) await sleep(1500); // deixa o envio dos arquivos terminar (o botão de enviar só habilita depois)
    return attached() ? files.length : 0;
  }

  async function run(prompt, timeoutMs, images, hardMs) {
    const s = await waitState(25000);
    if (s === "blocked") return { ok: false, error: "blocked" };
    if (s === "login") return { ok: false, error: "login" };
    const composer = first(SEL.composer);
    if (!composer) return { ok: false, error: "nopage:sem campo de texto" };
    const before = replyCount();
    if (images && images.length) {
      const n = await attachImages(composer, images);
      // O site não aceitou os quadros do vídeo: segue só com o texto (a transcrição) em vez de falhar tudo.
      if (!n) prompt = "(Observação: não consegui anexar os quadros do vídeo; baseie-se apenas no texto abaixo.)\n\n" + prompt;
    }
    setText(composer, prompt);
    await sleep(500);
    await send(composer);
    // Confere se o pedido saiu de verdade (campo esvaziou, botão de parar apareceu ou já há resposta). Senão tenta de novo uma vez.
    const wentOut = async (ms) => {
      for (let i = 0; i < ms / 300; i += 1) {
        const left = (composer.innerText || composer.value || composer.textContent || "").replace(/\s+/g, "").length;
        if (first(SEL.stop) || replyCount() > before || left < Math.floor(prompt.replace(/\s+/g, "").length * 0.3)) return true;
        await sleep(300);
      }
      return false;
    };
    if (!(await wentOut(6000))) {
      pressEnter(composer);
      const again = first(SEL.send);
      if (again && !again.disabled) again.click();
      if (!(await wentOut(6000))) return { ok: false, error: "failed:o site não aceitou o envio do pedido" };
    }

    const deadline = Date.now() + timeoutMs;
    // Prazo máximo: enquanto o site ainda trabalha neste pedido, esperar vale mais que recomeçar numa conversa nova.
    const hardDeadline = Date.now() + Math.max(timeoutMs, Number(hardMs) || 0);
    let started = false;
    let lastText = "";
    let stableSince = 0;
    let sawGenerating = false;
    let generating = false;
    while (clipgringaKeepWaiting(Date.now(), deadline, hardDeadline, generating)) {
      await sleep(700);
      if (challenge()) return { ok: false, error: "blocked" };
      generating = !!first(SEL.stop);
      if (generating) sawGenerating = true;
      if (generating || replyCount() > before || afterPrompt(prompt).length > 0) started = true;
      let text = lastReply();
      if (!text || replyCount() <= before) text = started ? afterPrompt(prompt) : "";
      if (!started) continue;
      if (text !== lastText) { lastText = text; stableSince = Date.now(); continue; }
      // Só entrega quando a resposta terminou de verdade: sem o rótulo do site no lugar da resposta e sem JSON pela metade.
      const done = clipgringaReplyDone(prompt, text, Date.now() - stableSince, generating, sawGenerating);
      if (done) return { ok: true, text: done };
    }
    return { ok: false, error: clipgringaCleanReply(lastText) ? "timeout:resposta incompleta" : "timeout" };
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message) return;
    if (message.type === "clipgringa-ai-probe") {
      waitState(message.wait ? 12000 : 800).then((s) => sendResponse({ ok: true, site: SITE, state: s }));
      return true;
    }
    if (message.type === "clipgringa-ai-run" && message.site === SITE) {
      run(String(message.prompt || ""), Number(message.timeoutMs) || 100000, message.images, Number(message.hardMs) || 0)
        .then(sendResponse)
        .catch((e) => sendResponse({ ok: false, error: "failed:" + String((e && e.message) || e).slice(0, 120) }));
      return true;
    }
  });
})();
