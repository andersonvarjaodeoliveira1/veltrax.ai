/* ClipGringa · Flow — ponte com o site do ClipGringa: responde se a conta do Flow está conectada. */
(function () {
  "use strict";
  // Se esta aba ainda tem a ponte de uma versão anterior (extensão atualizada sem recarregar a página), ela é desligada e esta assume.
  try { if (typeof window.__clipgringaBridgeOff === "function") window.__clipgringaBridgeOff(); } catch (_e) { /* ponte antiga já morta */ }
  const offs = [];
  const on = (fn) => { window.addEventListener("message", fn); offs.push(() => window.removeEventListener("message", fn)); };
  window.__clipgringaBridgeOff = () => offs.forEach((off) => off());
  const KEY = "clipgringa-flow-account-v1";

  const PENDING = "clipgringa-flow-pending-v1";
  // Recebe o pacote do site e guarda para a aba do Flow começar sozinha.
  on(async (event) => {
    if (event.source !== window || !event.data || event.data.source !== "clipgringa-page" || event.data.type !== "flow-package") return;
    let ok = false;
    try {
      const up = event.data.upload;
      const upload = up && typeof up.url === "string" && typeof up.token === "string" && /^https:\/\//.test(up.url)
        ? { url: up.url, token: up.token, package: String(up.package || "").slice(0, 120) } : null;
      // Pacote novo (diferente do anterior): apaga as imagens e o andamento do projeto antigo, para a tela não mostrar cena de outro vídeo.
      try {
        const prev = (await chrome.storage.local.get("clipgringa-flow-last-v1"))["clipgringa-flow-last-v1"];
        if (!prev || prev.raw !== String(event.data.raw || "")) await chrome.storage.local.remove(["clipgringa-flow-images-v1", "clipgringa-flow-progress-v1"]);
      } catch (_e) { /* ignora */ }
      await chrome.storage.local.set({ "clipgringa-flow-last-v1": { raw: String(event.data.raw || ""), at: Date.now(), upload } });
      await chrome.storage.local.set({ [PENDING]: { raw: String(event.data.raw || ""), at: Date.now(), upload } });
      ok = true;
      try { chrome.runtime.sendMessage({ type: "clipgringa-open-flow" }, () => void chrome.runtime.lastError); } catch (_e) { /* ignore */ }
    } catch (_e) { /* extensão recarregada */ }
    window.postMessage({ source: "clipgringa-flow", type: "package-ack", ok }, window.location.origin);
  });

  // O site pede para ler um anúncio da Shopee no navegador da pessoa (a Shopee bloqueia o servidor, não o navegador).
  on((event) => {
    if (event.source !== window || !event.data || event.data.source !== "clipgringa-page" || event.data.type !== "shopee-read") return;
    const id = String(event.data.id || "");
    const url = String(event.data.url || "");
    window.postMessage({ source: "clipgringa-flow", type: "shopee-ack", id }, window.location.origin);
    try {
      chrome.runtime.sendMessage({ type: "clipgringa-shopee", url }, (resp) => {
        void chrome.runtime.lastError;
        window.postMessage({ source: "clipgringa-flow", type: "shopee-result", id, data: resp || { ok: false, error: "failed" } }, window.location.origin);
      });
    } catch (_e) {
      window.postMessage({ source: "clipgringa-flow", type: "shopee-result", id, data: { ok: false, error: "failed" } }, window.location.origin);
    }
  });

  // O usuário abriu o chat de mudanças: avisa a aba do Flow para parar na etapa atual.
  on(async (event) => {
    if (event.source !== window || !event.data || event.data.source !== "clipgringa-page" || event.data.type !== "flow-stop") return;
    try { await chrome.storage.local.set({ "clipgringa-flow-stop-v1": { at: Date.now() } }); } catch (_e) { /* extensão recarregada */ }
  });

  // Andamento da geração no Flow, repassado para a página do ClipGringa.
  const PROGRESS = "clipgringa-flow-progress-v1";
  try {
    chrome.storage.onChanged.addListener((changes) => {
      if (changes[PROGRESS] && changes[PROGRESS].newValue) window.postMessage({ source: "clipgringa-flow", type: "progress", data: changes[PROGRESS].newValue }, window.location.origin);
    });
  } catch (_e) { /* extensão recarregada */ }
  on(async (event) => {
    if (event.source !== window || !event.data || event.data.source !== "clipgringa-page" || event.data.type !== "progress?") return;
    try { const d = (await chrome.storage.local.get(PROGRESS))[PROGRESS]; if (d) window.postMessage({ source: "clipgringa-flow", type: "progress", data: d }, window.location.origin); } catch (_e) { /* ignore */ }
  });

  const IMAGES = "clipgringa-flow-images-v1";
  try {
    chrome.storage.onChanged.addListener((changes) => {
      if (changes[IMAGES] && changes[IMAGES].newValue) window.postMessage({ source: "clipgringa-flow", type: "images", data: changes[IMAGES].newValue }, window.location.origin);
    });
  } catch (_e) { /* extensão recarregada */ }
  on(async (event) => {
    if (event.source !== window || !event.data || event.data.source !== "clipgringa-page" || event.data.type !== "images?") return;
    try { const d = (await chrome.storage.local.get(IMAGES))[IMAGES]; if (d) window.postMessage({ source: "clipgringa-flow", type: "images", data: d }, window.location.origin); } catch (_e) { /* ignore */ }
  });

  on(async (event) => {
    if (event.source !== window || !event.data || event.data.source !== "clipgringa-page" || event.data.type !== "flow-status?") return;
    let data = {};
    let tabs = null;
    try {
      tabs = await new Promise((res) => {
        const t = setTimeout(() => res(null), 2200);
        chrome.runtime.sendMessage({ type: "clipgringa-refresh-account" }, (r) => { void chrome.runtime.lastError; clearTimeout(t); res(r && typeof r.tabs === "number" ? r.tabs : null); });
      });
    } catch (_e) { /* segue com o que está guardado */ }
    try {
      data = ((await chrome.storage.local.get(KEY))[KEY]) || {};
    } catch (_e) { return; /* extensão recarregada: sem resposta */ }
    window.postMessage(
      {
        source: "clipgringa-flow",
        type: "status",
        version: chrome.runtime.getManifest().version,
        loggedIn: data.loggedIn !== false,
        plan: data.plan || null,
        credits: typeof data.credits === "number" ? data.credits : null,
        seenAt: data.seenAt || null,
        flowTabs: tabs,
      },
      window.location.origin
    );
  });
})();
